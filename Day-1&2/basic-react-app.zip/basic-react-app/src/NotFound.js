import React from "react";
const NotFound = () => {
return<>
        <h1> Sorry Page not found!!!🥲</h1>
        <img src={"https://www.digitalmesh.com/blog/wp-content/uploads/2020/05/404-error.jpg"} alt="404 Page Not Found" />
    </>;
}
export default NotFound;
// const NoPage = () => {
//     return <h1>404</h1>;
//   };
  
//   export default NoPage;